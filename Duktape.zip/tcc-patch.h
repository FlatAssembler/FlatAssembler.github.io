#include <math.h>
#define and &&
#define or ||

void *my_udata=NULL;

double cbrt(double x)
{
        return pow(x,1./3);
}

double log2(double x)
{
        return log(x)/log(2.);
}

static duk_ret_t getIEEE754(duk_context *ctx)
{
    static char polje[16];
    float broj=duk_to_number(ctx,0);
    sprintf(polje,"0x%X",*(int*)(&broj));
    duk_push_string(ctx,polje);
    return 1;
}
