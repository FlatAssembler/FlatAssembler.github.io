	char *compilerString=calloc(100*1024*sizeof(char),sizeof(char));
    if (!compilerString)
    {
        fprintf(stderr,"Not enough memory to intialize the program?!\n");
        return 1;
    }
    char *line=calloc(50*1024*sizeof(char),sizeof(char));
    fprintf(stderr,"Reading JavaScript from file!\n");
    fflush(stderr);
    FILE *input=fopen("compiler.js","r");
    if (!input)
    {
        fprintf(stderr,"Can't open 'compiler.js'?!\n");
        return 1;
    }
    while (!feof(input))
        if (fscanf(input,"%[^\n]\n",line)){
            strcat(line,"\n");
            strcat(compilerString,line);
        }
    fclose(input);

