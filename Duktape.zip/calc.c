#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "duktape.h"
#include "tcc-patch.h"

void my_fatal(void *udata, const char *msg) {
    fprintf(stderr,"FATAL ERROR: %s\n",(msg?msg:"no message"));
    exit(1);
}

void catch(void *ctx)
{
    fprintf(stderr,"JavaScript reports the following error:\n\"%s\"\n",duk_safe_to_string(ctx,-1));
    duk_destroy_heap(ctx);
    exit(1);
}

int main()
{
#include "readCompiler.h"
    fprintf(stderr,"Initializing Duktape!\n");
    fflush(stderr);
    duk_context *ctx=duk_create_heap(NULL,NULL,NULL,my_udata,my_fatal);
    duk_push_c_function(ctx,getIEEE754,1);
    duk_put_global_string(ctx,"getIEEE754");
    duk_eval_string(ctx,compilerString);
    free(compilerString);free(line);
    char arth[1024];
    fprintf(stderr,"Enter an arithmetic expression:\n");
    fflush(stderr);
    scanf("%[^\n]",arth);
    compilerString=calloc(1024,sizeof(char));
    strcat(compilerString,
        "assembler=\"\";\n"
        "asm(\"finit\");\n"
        "parseArth(tokenizeArth(\"");
    strcat(compilerString,arth);
    strcat(compilerString,"\")).compile();\n"
           "asm(\"fstp dword [result]\");\n"
           "assembler");
    duk_push_string(ctx,compilerString);
    free(compilerString);
    if (duk_peval(ctx)) catch(ctx);
    else {
        fprintf(stderr,"Its i486-compatible assembly is:\n");
        fflush(stderr);
        const char *assembly=duk_get_string(ctx,-1);
        char *output=calloc(64*1024,sizeof(char));
        output=strncpy(output,assembly,strlen(assembly)-1);
        printf("%s\n",output);
        free(output);
        fflush(stdout);
        char input[16];
        do {
            fprintf(stderr,"Do you want to interpret it? (YES/NO)\n");
            fflush(stderr);
            scanf("%s",input);
        } while (strcmp(input,"YES") and strcmp(input,"NO"));
        if (!strcmp(input,"YES"))
        {
            compilerString=calloc(1024,sizeof(char));
            strcat(compilerString,"parseArth(tokenizeArth(\"");
            strcat(compilerString,arth);
            strcat(compilerString,"\")).interpret()");
            duk_push_string(ctx,compilerString);
            free(compilerString);
            if (duk_peval(ctx))
                catch(ctx);
            printf(";The pointer 'result' should point to the value: %f\n",duk_get_number(ctx,-1));
            fflush(stdout);
        }
    }
    fprintf(stderr,"By the way, the standard output contains valid FlatAssembler-compilable assembly you can save to a file by using command-line redirection!\n");
	duk_destroy_heap(ctx);
}
