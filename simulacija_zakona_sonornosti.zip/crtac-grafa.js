"use strict";
const consonants = "bcčćdđfghjklmnpqrsštvwxyzž";
const fileSystem = require("fs");
const input = fileSystem.readFileSync(
    "hr.wl", // The Aspell word-list for the Croatian language.
    {encoding : "utf-8"});
const wordList = new Set();
let currentWord = "";
for (const character of input)
  if (character == '\n' || character == ' ') {
    wordList.add(currentWord);
    currentWord = "";
  } else
    currentWord += character.toLowerCase();
const mapWithWordInitialConsonantPairs = new Map();
const mapWithWordFinalConsonantPairs = new Map();
const setWithConsonantPairs = new Set();
const getFirstTwoConsonants = (word) => {
  let consonantPair = "";
  for (let i = 0; i < word.length; i++)
    if (consonants.includes(word[i])) {
      consonantPair += word[i];
      if (consonantPair.length == 2)
        break;
    }
  while (consonantPair.length < 2)
    consonantPair += "0";
  return consonantPair;
};
const getLastTwoConsonants = (word) => {
  let consonantPair = "";
  for (let i = word.length - 1; i >= 0; i--)
    if (consonants.includes(word[i])) {
      consonantPair = word[i] + consonantPair;
      if (consonantPair.length == 2)
        break;
    }
  while (consonantPair.length < 2)
    consonantPair = "0" + consonantPair;
  return consonantPair;
};
for (const word of wordList) {
  mapWithWordInitialConsonantPairs.set(
      getFirstTwoConsonants(word),
      (mapWithWordInitialConsonantPairs.get(getFirstTwoConsonants(word)) || 0) +
          1);
  mapWithWordFinalConsonantPairs.set(
      getLastTwoConsonants(word),
      (mapWithWordFinalConsonantPairs.get(getLastTwoConsonants(word)) || 0) +
          1);
  setWithConsonantPairs.add(getFirstTwoConsonants(word));
  setWithConsonantPairs.add(getLastTwoConsonants(word));
}
let maximalNumber = 0;
console.log("Consonant pair\tWords starting with it\tWords ending with it");
for (const consonantPair of setWithConsonantPairs) {
  console.log(consonantPair + "\t" +
              (mapWithWordInitialConsonantPairs.get(consonantPair) || 0) +
              "\t" + (mapWithWordFinalConsonantPairs.get(consonantPair) || 0));
  maximalNumber = Math.max(
      maximalNumber,
      Math.sqrt(mapWithWordInitialConsonantPairs.get(consonantPair) || 0),
      Math.sqrt(mapWithWordFinalConsonantPairs.get(consonantPair) || 0));
}
console.log("The maximal number is:" + maximalNumber);
let svg = `<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<svg
	width="${(consonants.length + 3) * 30}"
	height="${(consonants.length + 4) * 30}"
	version="1.1"
	xmlns="http://www.w3.org/2000/svg"
>
<rect x="0" y="0" width="100%" height="100%" fill="white" />
<text x="400" y="20">Prvi suglasnik u paru</text>
<g transform="rotate(-90 20 500)"><text x="20" y="500">Drugi suglasnik u paru</text></g>
`;
for (let i = 0; i < (consonants + "0").length; i++)
  svg += `<text x="${(i + 2) * 30 + 12}" y="${15 + 30}">${
      (consonants + "0")[i]}</text>
	<text x="${12 + 30}" y="${(i + 1) * 30 + 7 + 30}">${
      (consonants + "0")[i]}</text>
	`;
svg += `<line x1="${60}" y1="${30}" x2="${60}" y2="${
    ((consonants + "0").length + 1) * 30 + 30}" stroke="black" />
<line x1="${30}" y1="${20 + 30}" x2="${
    ((consonants + "0").length + 1) * 30 +
    30}" y2="${20 + 30}" stroke="black" />`;
for (let i = 0; i < (consonants + "0").length; i++)
  for (let j = 0; j < (consonants + "0").length; j++) {
    const consonantPair = (consonants + "0")[i] + (consonants + "0")[j];
    const proportionInBeginning =
        Math.sqrt(mapWithWordInitialConsonantPairs.get(consonantPair) || 0) /
        maximalNumber;
    const proportionAtTheEnd =
        Math.sqrt(mapWithWordFinalConsonantPairs.get(consonantPair) || 0) /
        maximalNumber;
    console.log(`The consonant pair ${consonantPair} has proportions ${
        proportionInBeginning} and ${proportionAtTheEnd}.`);
    const rx = (i + 2) * 30 + 15;
    const ry = (j + 2) * 30 + 3;
    svg += `<circle cx="${rx}" cy="${ry}" stroke="red" stroke-width="1" r="${
        proportionInBeginning * 13}"  fill="rgba(255,0,0,0.5)" />
			<rect x="${rx - proportionAtTheEnd * 13}" y="${
        ry - proportionAtTheEnd *
                 13}" width="${proportionAtTheEnd * 2 * 13}" height="${
        proportionAtTheEnd * 2 *
        13}"  fill="rgba(0,0,255,0.5)" stroke="blue" stroke-width="1" />
			`;
  }
svg += `<rect x="10" y="${
    ((consonants + "0").length + 2) * 30 +
    5}" stroke="blue" stroke-width="1" width="10" height="10"  fill="rgba(0,0,255,0.5)" /><text x="30" y="${
    ((consonants + "0").length + 2) * 30 +
    15}"> - Frekvencija para suglasnika na kraju riječi</text>
<circle cx="380" cy="${
    ((consonants + "0").length + 2) * 30 +
    10}" stroke-width="1" stroke="red" r="5"  fill="rgba(255,0,0,0.5)" /><text x="400" y="${
    ((consonants + "0").length + 2) * 30 +
    15}"> - Frekvencija para suglasnika na početku riječi</text>
`
svg += "</svg>";
fileSystem.writeFileSync("table-diagram-for-Croatian.svg", svg);
