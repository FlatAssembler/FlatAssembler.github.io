/*
 * Nakon što sam objavio YouTube video o svojoj alternativnoj interpretaciji
 * naziva rijeka u Hrvatskoj na latinskom jeziku, na jednom internetskom forumu
 * primio sam ovakvu primjedbu: "Kako se meni čini, tvoja kompjuterska
 * simulacija ne uzima u obzir pozicionalnu varijaciju frekvencije parova
 * suglasnika zbog zakona sonornosti slogova. Naime, čini mi se da tvoja
 * kompjuterska simulacija pretpostavlja da, ako se neki par suglasnika često
 * ponavlja na kraju riječi, on će se često pojavljivati i na početku riječi. To
 * nije istina, a za jezike s mnogo suglasničkih skupova na počecima i krajevima
 * riječi, kao što su hrvatski ili engleski, pogotovo nije istina. Zakon
 * sonornosti slogova sugerirao bi da je upravo suprotno istina. To je greška
 * zbog koje bi se bi, po meni, trebao približno udvostručiti Simpsonov indeks
 * koincidencije parova suglasnika, a kolizijska entropija parova suglasnika
 * smanjiti za približno jedan bit po paru suglasnika. Dakle, da kolizijska
 * entropija fonotaktike nije približno 1.6 bita po paru suglasnika, nego
 * približno 2.6 bitova po paru suglasnika. To bi p-vrijednost povećalo s 1/17
 * na približno 1/sqrt(17) što je nešto malo više od 20%. To možeš provjeriti i
 * bez računanja kolizijske entropije: u svojoj kompjuterskoj simulaciji
 * tokeniziraj listu riječi, te uzimaj oko 100 nasumičnih riječi iz liste, a za
 * svaku riječ uzimaj prva dva suglasnika. Napravi mapu pomoću koje ćeš
 * bilježiti koliko se često neki par suglasnika ponavlja. Pretpostavljam da ćeš
 * dobiti da je najveći broj u toj mapi veći od 6 približno 20% puta.". Hajdemo
 * to isprobati!
 */

"use strict";
if (typeof require != "function")
  (print || console.log)("Molimo pokrenite ovaj program u NodeJS-u!");
const datotecniSustav = require("fs");
const ulazniString = datotecniSustav.readFileSync("hr.wl", {
  encoding : "utf-8"
}); //"hr.wl" je Aspellova lista riječi za hrvatski jezik.
let trenutnaRijec = "", listaRijeci = [];
for (const znak of ulazniString)
  if (znak == '\n') {
    listaRijeci.push(trenutnaRijec);
    trenutnaRijec = "";
  } else
    trenutnaRijec += znak.toLowerCase();
console.log(`U listi se nalazi ${listaRijeci.length} riječi.`);
const iznad_koliko_kolizija_brojimo =
    6, // Krka, Korana, Krapina, Krbavica, Kravarščica, 2*Karašica.
    koliko_cemo_puta_izvrtjeti_simulaciju = 10_000;
let koliko_smo_puta_dobili_toliko_kolizija = 0,
    koliko_smo_puta_dobili_toliko_kr_ova = 0;
const suglasnici = "bcčćdđfghjklmnpqrsštvwxyzž";
const dajPrvaDvaSuglasnika = (rijec) => {
  let vrijednostKojuVracamo = "";
  for (const znak of rijec)
    if (suglasnici.includes(znak)) {
      vrijednostKojuVracamo += znak;
      if (vrijednostKojuVracamo.length == 2)
        break;
    }
  while (vrijednostKojuVracamo.length < 2)
    vrijednostKojuVracamo += "0";
  return vrijednostKojuVracamo;
};
console.log(
    "Lambda-funkcija dajPrvaDvaSuglasnika za string \"korana\" vraća: " +
    dajPrvaDvaSuglasnika("korana"));
const broj_rijeka_u_Hrvatskoj = 100;
for (let i = 0; i < koliko_cemo_puta_izvrtjeti_simulaciju; i++) {
  const mapa = new Map();
  const simulirani_nazivi_rijeka = [];
  for (let i = 0; i < broj_rijeka_u_Hrvatskoj; i++)
    simulirani_nazivi_rijeka.push(
        listaRijeci[Math.floor(Math.random() * listaRijeci.length) | 0]);
  for (const naziv_rijeke of simulirani_nazivi_rijeka)
    mapa.set(dajPrvaDvaSuglasnika(naziv_rijeke),
             (mapa.get(dajPrvaDvaSuglasnika(naziv_rijeke)) || 0) + 1);
  let jesmo_li_dobili_trazeni_broj_kolizija = false;
  let najveciBrojKolizija = 0, najcesciParSuglasnika = "00";
  mapa.forEach((vrijednost, kljuc) => {
    if (vrijednost > najveciBrojKolizija) {
      najveciBrojKolizija = vrijednost;
      najcesciParSuglasnika = kljuc;
    }
    if (vrijednost > iznad_koliko_kolizija_brojimo)
      jesmo_li_dobili_trazeni_broj_kolizija = true;
  });
  if (jesmo_li_dobili_trazeni_broj_kolizija)
    koliko_smo_puta_dobili_toliko_kolizija++;
  console.log(`U simulaciji #${i}, najčešći par suglasnika bio je ${
      najcesciParSuglasnika}, i on se pojavio ${
      najveciBrojKolizija} puta. Par suglasnika kr pojavio se ${
      mapa.get("kr") || 0} puta.`);
  if ((mapa.get("kr") || 0) > iznad_koliko_kolizija_brojimo)
    koliko_smo_puta_dobili_toliko_kr_ova++;
}
console.log(`P-vrijednost uzorka da ${iznad_koliko_kolizija_brojimo} od ${
    broj_rijeka_u_Hrvatskoj} naziva rijeka počinje istim parom suglasnika iznosi ${
    100 *
    (koliko_smo_puta_dobili_toliko_kolizija /
     koliko_cemo_puta_izvrtjeti_simulaciju)}%. P-vrijednost uzorka da ih toliko bude na k-r iznosi ${
    100 * (koliko_smo_puta_dobili_toliko_kr_ova /
           koliko_cemo_puta_izvrtjeti_simulaciju)}%.`);
// Ovaj program ispisuje: "P-vrijednost uzorka da 6 od 100 naziva rijeka počinje
// istim parom suglasnika iznosi 86.50999999999999%. P-vrijednost uzorka da ih
// toliko bude na k-r iznosi 0.43%."
